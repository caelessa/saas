# Edição e inativação de veículos

Foi adicionada a opção **Editar** na lista de veículos.

Agora é possível alterar todos os dados principais e o status para:

- Disponível
- Alugado
- Manutenção
- Bloqueado
- Inativo
- Vendido

Veículos com contratos anteriores continuam impedidos de exclusão definitiva para preservar o histórico contratual. Nesses casos, use **Inativo** ou **Vendido**.
